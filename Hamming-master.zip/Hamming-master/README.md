Hamming
=======

Hamming(12,8) and (24,16) error-correcting code (ECC) in avr-gcc
